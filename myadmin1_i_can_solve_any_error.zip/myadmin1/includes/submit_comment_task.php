<?php 
session_start();
include "db.php";

		
// Check if the user is already logged in, if yes then redirect him to welcome page

// Include config file

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
   }
   

$userid = $_SESSION['id'];
$query = "SELECT * FROM users WHERE id=" . $userid;
$res = mysqli_query($con, $query);
 while ($row = mysqli_fetch_assoc($res)) {
	 $user_username = $row['username'];
	 $creator = $row['name'];
	 $user_image = $row['image'];
	
 }

		// get the values from the assgin task form

if($_SERVER["REQUEST_METHOD"] == "POST"){

		$ucomment = test_input($_POST['notes']);
		$zft = test_input($_POST['why']);
		// "UPDATE todo SET comment =`" . $ucomment ."` WHERE id=".$task_id;
$query = "UPDATE `todo` SET `note` = ? WHERE `id` = ?";
$stmt = $con->prepare($query);
$stmt->bind_param("si", $ucomment, $zft);


if ($stmt->execute()) {
	echo $_SERVER["REQUEST_METHOD"];
	echo $zft;
	echo $ucomment;
} else {
	echo $_SERVER["REQUEST_METHOD"];
	echo $zft;
	echo $ucomment;
	
}
} else {
   echo $_SERVER["REQUEST_METHOD"];
}





//$lock = 'UPDATE todo SET note=' . $ucomment .'$ucomment WHERE id='.$task_id;
//$myresult = mysqli_query($con, $myresult);	
	






 

    
// Close connection
mysqli_close($con);

?>