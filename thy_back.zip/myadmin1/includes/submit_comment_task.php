<?php 
session_start();
include "db.php";

		
// Check if the user is already logged in, if yes then redirect him to welcome page

// Include config file

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
   }
   

$userid = $_SESSION['id'];
$query = "SELECT * FROM users WHERE id=" . $userid;
$res = mysqli_query($con, $query);
 while ($row = mysqli_fetch_assoc($res)) {
	 $user_username = $row['username'];
	 $creator = $row['name'];
	 $user_image = $row['image'];
	
 }

		// get the values from the assgin task form


        $task_id = $_GET['task'];
		$ucomment = test_input($_GET['comment']);



// "UPDATE todo SET comment =`" . $ucomment ."` WHERE id=".$task_id;

$lock = 'UPDATE todo SET comment = $ucomment WHERE id='.$task_id;
$myresult = mysqli_query($con, $myresult);	
	
header("location: ../index.php");





 

    
// Close connection
mysqli_close($con);

?>