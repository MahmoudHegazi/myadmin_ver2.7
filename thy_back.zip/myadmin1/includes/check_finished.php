<?php 
session_start();
include "db.php";
global $con;

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
$userid = $_SESSION['id'];

?>








<!DOCTYPE html>
<html lang="en">
<head>
  <title>Check Finished Tasks</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>

<a href="../index.php"><button class="btn btn-success"><i style="font-size:24px" class="fa">&#xf015;</i> Back Home</button></a>
<div class="container">
  <h2 style="text-align:center;">Completed Tasks</h2>
          <br />
  <table class="table table-dark table-striped table-hover">
    <thead>
      <tr>
        <th>ID</th>
        <th>Title</th>
		<th>Doer</th>
		<th>Finish Date</th>
		<th>Body</th>
      </tr>
    </thead>
    <tbody>
	
	
	<?php 

$query = "SELECT * FROM task_archive WHERE task_assigner=" . $userid;
$result = mysqli_query($con, $query);
while ($row = mysqli_fetch_assoc($result)) {
	$task_id = $row['task_id'];
	$task_title = $row['task_title'];
	$task_doer = $row['user_id'];
	$task_body = $row['task_body'];
	$task_finished_date = $row['finish_date'];
	$task_comment = $row['comment'];
	

	echo "<tr>";
	echo "<td>" . $task_id . "</td>";  
	echo "<td>" . $task_title . "</td>";
	echo "<td>" . $task_doer . "</td>";
	echo "<td>" . $task_finished_date . "</td>";
	echo "<td style='width:30%;'>" . $task_body . "</td>";
	echo "<td style='width:30%;'>" . $task_comment . "</td>";
	echo "</tr>";
}



mysqli_close($con);


?>

    </tbody>
  </table>
</div>


</body>
</html>
